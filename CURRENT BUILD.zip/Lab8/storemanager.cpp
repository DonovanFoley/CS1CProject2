#include "storemanager.h"
#include "ui_storemanager.h"
#include "login_db.h"
#include "ui_login_db.h"
#include "displayrebate.h"
#include "expiringmembers.h"
#include "adddelete.h"
#include "adddeleteitems.h"
#include "createpurchases.h"
#include "displayitemssold.h"
#include "salesreport.h"
#include "searchmembernumber.h"
#include "productdisplay.h"
#include "totalpurchases.h"
#include "login.h"


StoreManager::StoreManager(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::StoreManager)
{
    ui->setupUi(this);
}

StoreManager::~StoreManager()
{
    delete ui;
}

void StoreManager::on_pushButtonGotoDR_clicked()
{
    DisplayRebate secondDialog;

    secondDialog.setModal(true);
    secondDialog.exec();
}

void StoreManager::on_pushButtonGotoEM_clicked()
{
    ExpiringMembers secondDialog;

    secondDialog.setModal(true);
    secondDialog.exec();
}

void StoreManager::on_pushButtonGotoDR_2_clicked()
{
    DisplayItemsSold secondDialog;

    secondDialog.setModal(true);
    secondDialog.exec();
}

void StoreManager::on_pushButtonGotoSR_clicked()
{
    salesreport secondDialog;

    secondDialog.setModal(true);
    secondDialog.exec();
}

void StoreManager::on_pushButtonGotoSM_clicked()
{
    SearchMemberNumber secondDialog;

    secondDialog.setModal(true);
    secondDialog.exec();
}

void StoreManager::on_pushButtonGotoSR_2_clicked()
{
    ProductDisplay secondDialog;

    secondDialog.setModal(true);
    secondDialog.exec();
}

void StoreManager::on_pushButtonGotoSR_3_clicked()
{
    totalPurchases secondDialog;

    secondDialog.setModal(true);
    secondDialog.exec();
}
