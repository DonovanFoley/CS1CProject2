#include "login.h"
#include "ui_login.h"
#include "storemanager.h"

Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);
}

Login::~Login()
{
    delete ui;
}

void Login::on_pushButton_clicked()
{
    if(ui->lineEdit_P->text() == "1111")
    {
        StoreManager secondDialog;

        secondDialog.setModal(true);
        secondDialog.exec();
    }
}
