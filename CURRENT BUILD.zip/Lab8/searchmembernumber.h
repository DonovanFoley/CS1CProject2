#ifndef SEARCHMEMBERNUMBER_H
#define SEARCHMEMBERNUMBER_H

#include <QDialog>

namespace Ui {
class SearchMemberNumber;
}

class SearchMemberNumber : public QDialog
{
    Q_OBJECT

public:
    explicit SearchMemberNumber(QWidget *parent = nullptr);
    ~SearchMemberNumber();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();



private:
    Ui::SearchMemberNumber *ui;
    void displayMemberInfo();
};

#endif // SEARCHMEMBERNUMBER_H
