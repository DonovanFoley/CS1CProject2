#ifndef STOREMANAGER_H
#define STOREMANAGER_H

#include <QDialog>

namespace Ui {
class StoreManager;
}

class StoreManager : public QDialog
{
    Q_OBJECT

public:
    explicit StoreManager(QWidget *parent = nullptr);
    ~StoreManager();

private slots:
    void on_pushButtonGotoSR_clicked();

    void on_pushButtonGotoSR_3_clicked();

    void on_pushButtonGotoDR_2_clicked();

    void on_pushButtonGotoDR_clicked();

    void on_pushButtonGotoEM_clicked();

    void on_pushButtonGotoSR_2_clicked();

    void on_pushButtonGotoSM_clicked();

private:
    Ui::StoreManager *ui;
};

#endif // STOREMANAGER_H
