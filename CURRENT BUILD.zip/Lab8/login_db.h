#ifndef LOGIN_DB_H
#define LOGIN_DB_H

#include <QMainWindow>
#include <QtSql>
#include <QtDebug>
#include <QFileInfo>
#include <QSqlTableModel>
#include <QDebug>
#include <QDialog>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QMainWindow>
#include "ExecutiveClass.h"
#include "mainwindow.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Login_DB; }
QT_END_NAMESPACE

class Login_DB : public QMainWindow
{
    Q_OBJECT

public:
    Login_DB(QWidget *parent = nullptr);
    ~Login_DB();

private slots:

    void on_pushButton_loadTable_clicked();

    void on_pushButtonGotoSR_4_clicked();

    void on_pushButtonGotoSR_5_clicked();

private:
    Ui::Login_DB *ui;
};
#endif // LOGIN_DB_H
