#include "salesreport.h"
#include "ui_salesreport.h"
#include "displayrebate.h"
#include "expiringmembers.h"
#include "adddelete.h"
#include "salesreport.h"
#include "day1.h"
#include <QTableWidget>


salesreport::salesreport(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::salesreport)
{
    ui->setupUi(this);



}

salesreport::~salesreport()
{

    delete ui;
}


void salesreport::on_pushButtonD1_clicked()
{

    QString date = "03/12/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDay(date);
    secondDialog.exec();
}



void salesreport::on_pushButtonD2_clicked()
{
    QString date = "03/13/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDay(date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD3_clicked()
{
    QString date = "03/14/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDay(date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD4_clicked()
{
    QString date = "03/15/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDay(date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD5_clicked()
{
    QString date = "03/16/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDay(date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD6_clicked()
{
    QString date = "03/17/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDay(date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD7_clicked()
{
    QString date = "03/18/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDay(date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD1_3_clicked()
{
    QString member = "Regular";
    QString date = "03/12/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD2_3_clicked()
{
    QString member = "Regular";
    QString date = "03/13/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD3_3_clicked()
{
    QString member = "Regular";
    QString date = "03/14/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD4_3_clicked()
{
    QString member = "Regular";
    QString date = "03/15/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD5_3_clicked()
{
    QString member = "Regular";
    QString date = "03/16/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD6_3_clicked()
{
    QString member = "Regular";
    QString date = "03/17/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD7_3_clicked()
{
    QString member = "Regular";
    QString date = "03/18/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD1_4_clicked()
{
    QString member = "Executive";
    QString date = "03/12/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD2_4_clicked()
{
    QString member = "Executive";
    QString date = "03/13/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD3_4_clicked()
{
    QString member = "Executive";
    QString date = "03/14/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD4_4_clicked()
{
    QString member = "Executive";
    QString date = "03/15/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD5_4_clicked()
{
    QString member = "Executive";
    QString date = "03/16/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD6_4_clicked()
{
    QString member = "Executive";
    QString date = "03/17/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}

void salesreport::on_pushButtonD7_4_clicked()
{
    QString member = "Executive";
    QString date = "03/18/2020";
    Day1 secondDialog;

    secondDialog.setModal(true);
    secondDialog.DisplayDayByMember(member, date);
    secondDialog.exec();
}
