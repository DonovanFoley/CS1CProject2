/********************************************************************************
** Form generated from reading UI file 'login_db.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_DB_H
#define UI_LOGIN_DB_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Login_DB
{
public:
    QWidget *centralwidget;
    QTableView *tableView;
    QPushButton *pushButton_loadTable;
    QPushButton *pushButtonGotoSR_4;
    QPushButton *pushButtonGotoSR_5;
    QLabel *label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Login_DB)
    {
        if (Login_DB->objectName().isEmpty())
            Login_DB->setObjectName(QString::fromUtf8("Login_DB"));
        Login_DB->resize(566, 350);
        centralwidget = new QWidget(Login_DB);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        tableView = new QTableView(centralwidget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(30, 10, 361, 231));
        pushButton_loadTable = new QPushButton(centralwidget);
        pushButton_loadTable->setObjectName(QString::fromUtf8("pushButton_loadTable"));
        pushButton_loadTable->setGeometry(QRect(400, 10, 161, 51));
        pushButtonGotoSR_4 = new QPushButton(centralwidget);
        pushButtonGotoSR_4->setObjectName(QString::fromUtf8("pushButtonGotoSR_4"));
        pushButtonGotoSR_4->setGeometry(QRect(40, 280, 151, 24));
        pushButtonGotoSR_5 = new QPushButton(centralwidget);
        pushButtonGotoSR_5->setObjectName(QString::fromUtf8("pushButtonGotoSR_5"));
        pushButtonGotoSR_5->setGeometry(QRect(210, 280, 151, 24));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(50, 250, 161, 16));
        Login_DB->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Login_DB);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 566, 21));
        Login_DB->setMenuBar(menubar);
        statusbar = new QStatusBar(Login_DB);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        Login_DB->setStatusBar(statusbar);

        retranslateUi(Login_DB);

        QMetaObject::connectSlotsByName(Login_DB);
    } // setupUi

    void retranslateUi(QMainWindow *Login_DB)
    {
        Login_DB->setWindowTitle(QCoreApplication::translate("Login_DB", "Login_DB", nullptr));
        pushButton_loadTable->setText(QCoreApplication::translate("Login_DB", "Reload Table", nullptr));
        pushButtonGotoSR_4->setText(QCoreApplication::translate("Login_DB", "Store Manager Login", nullptr));
        pushButtonGotoSR_5->setText(QCoreApplication::translate("Login_DB", "Admin Login", nullptr));
        label->setText(QCoreApplication::translate("Login_DB", "Main Window", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Login_DB: public Ui_Login_DB {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_DB_H
