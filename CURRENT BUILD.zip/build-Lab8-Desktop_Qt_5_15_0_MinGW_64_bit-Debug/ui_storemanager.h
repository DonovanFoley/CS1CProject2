/********************************************************************************
** Form generated from reading UI file 'storemanager.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STOREMANAGER_H
#define UI_STOREMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_StoreManager
{
public:
    QPushButton *pushButtonGotoEM;
    QPushButton *pushButtonGotoSR;
    QPushButton *pushButtonGotoSR_2;
    QPushButton *pushButtonGotoDR;
    QPushButton *pushButtonGotoDR_2;
    QPushButton *pushButtonGotoSR_3;
    QPushButton *pushButtonGotoSM;

    void setupUi(QDialog *StoreManager)
    {
        if (StoreManager->objectName().isEmpty())
            StoreManager->setObjectName(QString::fromUtf8("StoreManager"));
        StoreManager->resize(351, 154);
        pushButtonGotoEM = new QPushButton(StoreManager);
        pushButtonGotoEM->setObjectName(QString::fromUtf8("pushButtonGotoEM"));
        pushButtonGotoEM->setGeometry(QRect(20, 80, 151, 24));
        pushButtonGotoSR = new QPushButton(StoreManager);
        pushButtonGotoSR->setObjectName(QString::fromUtf8("pushButtonGotoSR"));
        pushButtonGotoSR->setGeometry(QRect(20, 20, 151, 24));
        pushButtonGotoSR_2 = new QPushButton(StoreManager);
        pushButtonGotoSR_2->setObjectName(QString::fromUtf8("pushButtonGotoSR_2"));
        pushButtonGotoSR_2->setGeometry(QRect(180, 80, 151, 24));
        pushButtonGotoDR = new QPushButton(StoreManager);
        pushButtonGotoDR->setObjectName(QString::fromUtf8("pushButtonGotoDR"));
        pushButtonGotoDR->setGeometry(QRect(180, 50, 151, 24));
        pushButtonGotoDR_2 = new QPushButton(StoreManager);
        pushButtonGotoDR_2->setObjectName(QString::fromUtf8("pushButtonGotoDR_2"));
        pushButtonGotoDR_2->setGeometry(QRect(20, 50, 151, 24));
        pushButtonGotoSR_3 = new QPushButton(StoreManager);
        pushButtonGotoSR_3->setObjectName(QString::fromUtf8("pushButtonGotoSR_3"));
        pushButtonGotoSR_3->setGeometry(QRect(180, 20, 151, 24));
        pushButtonGotoSM = new QPushButton(StoreManager);
        pushButtonGotoSM->setObjectName(QString::fromUtf8("pushButtonGotoSM"));
        pushButtonGotoSM->setGeometry(QRect(20, 110, 151, 24));

        retranslateUi(StoreManager);

        QMetaObject::connectSlotsByName(StoreManager);
    } // setupUi

    void retranslateUi(QDialog *StoreManager)
    {
        StoreManager->setWindowTitle(QCoreApplication::translate("StoreManager", "Dialog", nullptr));
        pushButtonGotoEM->setText(QCoreApplication::translate("StoreManager", "GoTo Expiring Members", nullptr));
        pushButtonGotoSR->setText(QCoreApplication::translate("StoreManager", "GoTo Sales Report", nullptr));
        pushButtonGotoSR_2->setText(QCoreApplication::translate("StoreManager", "GoTo Product Display", nullptr));
        pushButtonGotoDR->setText(QCoreApplication::translate("StoreManager", "GoTo Display Rebate", nullptr));
        pushButtonGotoDR_2->setText(QCoreApplication::translate("StoreManager", "GoTo Display Item Sold", nullptr));
        pushButtonGotoSR_3->setText(QCoreApplication::translate("StoreManager", "GoTo Total Purchases", nullptr));
        pushButtonGotoSM->setText(QCoreApplication::translate("StoreManager", "GoTo Search Members", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StoreManager: public Ui_StoreManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STOREMANAGER_H
