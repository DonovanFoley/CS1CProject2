#ifndef DAY1_H
#define DAY1_H

#include <QDialog>
#include "salesreport.h"

namespace Ui {
class Day1;
}

class Day1 : public QDialog
{
    Q_OBJECT

public:
    explicit Day1(QWidget *parent = nullptr);
    ~Day1();
    void DisplayDay(QString date, int regularIndex, int executiveIndex);
    void DisplayDayByMember(QString member, QString date,int regularIndex, int executiveIndex);
    double totalRevenue;


private slots:

private:
    Ui::Day1 *ui;

};

#endif // DAY1_H
