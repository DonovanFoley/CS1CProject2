#include "searchmembernumber.h"
#include "ui_searchmembernumber.h"
#include <QMessageBox>
#include "login_db.h"

SearchMemberNumber::SearchMemberNumber(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SearchMemberNumber)
{
    ui->setupUi(this);

}

SearchMemberNumber::~SearchMemberNumber()
{
    delete ui;
}
void SearchMemberNumber::displayMemberInfo()
{
    int index = 0;      //Input index
    int maxIndex = 0;   //used to determine table slots
    double priceWithQuantity;
    double totalRevenue = 0;

    ExecutiveMember execAR[350];    //array of ExecutiveMember
    QSqlQuery query;                //acceses customers

    QString firstName;
    QString lastName;
    QString id;                  //month chosen

    //INPUT - Gets month
    id = ui->lineEdit->text();
    firstName = ui->lineEdit_2->text();
    lastName = ui->lineEdit_3->text();

    //INPUT - customer data
    query.prepare("select * from customerPurchases");
    if(!query.exec())
    {
        qDebug() << "ERROR " << query.lastError();
    }
    while(query.next())
    {
        QString temp;                                   //temporary variable to get month
        QString temp1;
        QString temp2;
        QString idVariable = query.value(3).toString();   //temporary variable to get month
        QString firstVariable = query.value(1).toString();
        QString lastVariable = query.value(2).toString();
        temp = idVariable;
        temp1 = firstVariable;
        temp2 = lastVariable;

        if(id == idVariable || (firstName == firstVariable || lastName == lastVariable))
        {
          //Debugging
          //qDebug() << "I'm Here " << index;

          execAR[index].setFirstName(query.value(1).toString());
          execAR[index].setLastName(query.value(2).toString());
          execAR[index].setID(query.value(3).toString());
          execAR[index].setProductName(query.value(5).toString());
          execAR[index].setProductCost(query.value(6).toFloat());
          execAR[index].setProductQuantity(query.value(7).toInt());
          priceWithQuantity = execAR[index].getProductCost() * execAR[index].getProductQuantity();
          totalRevenue += priceWithQuantity;

          index++;
        }

    }


    maxIndex = index;
    //CALC - sorts low->high
    for(int i = 0; i< maxIndex; i++)
    {
        for(int i2 = i + 1; i2 < maxIndex; i2++)
        {
            if(execAR[i].getID() > execAR[i2].getID())
            {
                ExecutiveMember temp;
                temp  = execAR[i];
                execAR[i] = execAR[i2];
                execAR[i2] = temp;
            }
        }
    }


    //***BUILDS TABLE***//
    //ui->table
    //QTableWidget *table = new QTableWidget(this);
    ui->tableWidget->clear();
    ui->tableWidget->viewport()->update();
    ui->tableWidget->setRowCount(maxIndex);
    ui->tableWidget->setColumnCount(3);

    QStringList labels;     //used to set labels of table
    labels << "Product Name" << "Product Cost" << "Product Quantity" ;
    ui->tableWidget->setHorizontalHeaderLabels(labels);

    //Sets table data
    for(int i = 0; i < ui->tableWidget->rowCount(); i++)
    {
        QTableWidgetItem *item;
        for(int i2 = 0; i2 < ui->tableWidget->columnCount(); i2++)
        {
            item = new QTableWidgetItem;

            if(i2 == 0)
            {
                item->setText(execAR[i].getProductName());
            }
            if(i2 == 1)
            {
                item->setText(QString::number(execAR[i].getProductCost()));
            }
            if(i2 == 2)
            {
                item->setText(QString::number(execAR[i].getProductQuantity()));
            }

            ui->tableWidget->setItem(i,i2,item);
            qDebug() << totalRevenue;
            qDebug() << totalRevenue*0.0775;

            ui->label_5->setText(QString::number(totalRevenue+(totalRevenue*0.0775)));
            ui->label_6->setText(execAR[i].getFirstName());
            ui->label_7->setText(execAR[i].getLastName());
            ui->label_8->setText(QString::number(execAR[i].getID()));


        }
    }

    if(ui->tableWidget->rowCount() == 0)
    {
        QMessageBox::critical(this,tr("Error"),"This Member has NO purchases");
    }

}

void SearchMemberNumber::on_pushButton_clicked()
{
    displayMemberInfo();
}

void SearchMemberNumber::on_pushButton_2_clicked()
{
    displayMemberInfo();
}


