#ifndef CONVERTMEMBERSHIP_H
#define CONVERTMEMBERSHIP_H

#include <QDialog>

namespace Ui {
class convertMembership;
}

class convertMembership : public QDialog
{
    Q_OBJECT

public:
    explicit convertMembership(QWidget *parent = nullptr);
    ~convertMembership();

    void displayConvertMembership();

private:
    Ui::convertMembership *ui;
};


#endif // CONVERTMEMBERSHIP_H
