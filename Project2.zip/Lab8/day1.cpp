#include "day1.h"
#include "ui_day1.h"
#include "login_db.h"
#include "salesreport.h"

Day1::Day1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Day1)
{
    ui->setupUi(this);



}

Day1::~Day1()
{
    delete ui;
}


void Day1::DisplayDay(QString date, int regularIndex, int executiveIndex)
{
    int index = 0;
    double totalRevenue = 0;
    double priceWithQuantity = 0;
    QString firstname = "";
    QString lastname = "";
    QString Ar[50];


    RegularMember purchaseAR[350];  //array of regular member
    QSqlQuery query, query2; //qry=new QSqlQuery(mydb); //access customer purchases, second query

    query.prepare("select * from customerPurchases");

    if(!query.exec())
    {
            //qDebug() << "ERROR " << query.lastError().text;
    }
    while(query.next())
    {

        QString variable = query.value(0).toString();

        QString variable2 = query.value(4).toString();  //represents membership type


        if (variable == date)   //"03/12/2020"
        {
            purchaseAR[index].setDate(query.value(0).toString());
            purchaseAR[index].setFirstName(query.value(1).toString());
            purchaseAR[index].setLastName(query.value(2).toString());
            purchaseAR[index].setID(query.value(3).toString());
            purchaseAR[index].setMembership(query.value(4).toString());

            Ar[index] =purchaseAR[index].getID();

            purchaseAR[index].setProductName(query.value(5).toString());
            purchaseAR[index].setProductCost(query.value(6).toFloat());
            purchaseAR[index].setProductQuantity(query.value(7).toInt());
            //qDebug() << variable;
            priceWithQuantity = purchaseAR[index].getProductCost() * purchaseAR[index].getProductQuantity();
            totalRevenue += priceWithQuantity;
            index++;
        }
    }




        qDebug() << totalRevenue;
        //***BUILDS TABLE***//
        QTableWidget *table = new QTableWidget(this);
        table->setRowCount(index);
        table->setColumnCount(8);

        QStringList labels;
        labels << "Date" << "First Name" << "Last Name" << "ID" << "Membership" <<
                      "Product Name" << "Product Cost" << "Product Quantity";
        table->setHorizontalHeaderLabels(labels);

        //Formatting
        table->setMaximumWidth(850);
        table->setMinimumWidth(850);
        table->setMaximumHeight(500);
        table->setMinimumHeight(500);


        for(int i = 0; i < table->rowCount(); i++)
        {
            QTableWidgetItem *item;
            for(int i2 = 0; i2 < table->columnCount(); i2++)
            {
                item = new QTableWidgetItem;

                if(i2 == 0)
                {
                    item->setText(purchaseAR[i].getDate());
                }
                if(i2 == 1)
                {
                    item->setText(purchaseAR[i].getFirstName());
                }
                if(i2 == 2)
                {
                    item->setText(purchaseAR[i].getLastName());
                }
                if(i2 == 3)
                {
                    item->setText(QString::number(purchaseAR[i].getID()));
                }
                if(i2 == 4)
                {
                    item->setText(purchaseAR[i].getMembership());
                }
                if(i2 == 5)
                {
                    item->setText(purchaseAR[i].getProductName());
                }
                if(i2 == 6)
                {
                    item->setText(QString::number(purchaseAR[i].getProductCost()));
                }
                if(i2 == 7)
                {
                    item->setText(QString::number(purchaseAR[i].getProductQuantity()));
                }

                table->setItem(i,i2,item); 
            }
        }

        double taxes = 0;

        taxes = totalRevenue * 0.0775;
        qDebug() << "taxes : " << taxes;

        totalRevenue = totalRevenue + taxes;
        ui->label->setText(QString::number(totalRevenue, 'f', 2));

        ui->label_R->setText(QString::number(regularIndex));
        ui->label_E->setText(QString::number(executiveIndex));
}

//----------------------------------------------------------------------------
void Day1::DisplayDayByMember(QString member, QString date, int regularIndex, int executiveIndex)
{
    int index = 0;
    double totalRevenue = 0;
    double priceWithQuantity;
    QString firstname = "";
    QString lastname = "";


    RegularMember purchaseAR[350];  //array of regular member
    QSqlQuery query; //qry=new QSqlQuery(mydb); //access customer purchases

    query.prepare("select * from customerPurchases");

    if(!query.exec())
    {
            //qDebug() << "ERROR " << query.lastError().text;
    }
    while(query.next())
    {

        QString variable = query.value(4).toString();
        QString variable1 = query.value(0).toString();


        if (variable == member && variable1 == date)
        {
            purchaseAR[index].setDate(query.value(0).toString());
            purchaseAR[index].setFirstName(query.value(1).toString());
            purchaseAR[index].setLastName(query.value(2).toString());
            purchaseAR[index].setID(query.value(3).toString());
            purchaseAR[index].setMembership(query.value(4).toString());
            purchaseAR[index].setProductName(query.value(5).toString());
            purchaseAR[index].setProductCost(query.value(6).toFloat());
            purchaseAR[index].setProductQuantity(query.value(7).toInt());
            //qDebug() << variable;
            priceWithQuantity = purchaseAR[index].getProductCost() * purchaseAR[index].getProductQuantity();
            totalRevenue += priceWithQuantity;
            index++;

        }

    }

        qDebug() << totalRevenue;
        //***BUILDS TABLE***//
        QTableWidget *table = new QTableWidget(this);
        table->setRowCount(index);
        table->setColumnCount(8);

        QStringList labels;
        labels << "Date" << "First Name" << "Last Name" << "ID" << "Membership" <<
                      "Product Name" << "Product Cost" << "Product Quantity";
        table->setHorizontalHeaderLabels(labels);

        //Formatting
        table->setMaximumWidth(850);
        table->setMinimumWidth(850);
        table->setMaximumHeight(500);
        table->setMinimumHeight(500);


        for(int i = 0; i < table->rowCount(); i++)
        {
            QTableWidgetItem *item;
            for(int i2 = 0; i2 < table->columnCount(); i2++)
            {
                item = new QTableWidgetItem;

                if(i2 == 0)
                {
                    item->setText(purchaseAR[i].getDate());
                }
                if(i2 == 1)
                {
                    item->setText(purchaseAR[i].getFirstName());
                }
                if(i2 == 2)
                {
                    item->setText(purchaseAR[i].getLastName());
                }
                if(i2 == 3)
                {
                    item->setText(QString::number(purchaseAR[i].getID()));
                }
                if(i2 == 4)
                {
                    item->setText(purchaseAR[i].getMembership());
                }
                if(i2 == 5)
                {
                    item->setText(purchaseAR[i].getProductName());
                }
                if(i2 == 6)
                {
                    item->setText(QString::number(purchaseAR[i].getProductCost()));
                }
                if(i2 == 7)
                {
                    item->setText(QString::number(purchaseAR[i].getProductQuantity()));
                }

                table->setItem(i,i2,item);



            }

        }
        double taxes = 0;
        taxes = totalRevenue * 0.0775;


        totalRevenue += taxes;
        ui->label->setText(QString::number(totalRevenue, 'f', 2));
        ui->label_R->setText(QString::number(regularIndex));
        ui->label_E->setText(QString::number(executiveIndex));
}

