#ifndef SALESREPORT_H
#define SALESREPORT_H

#include "login_db.h"

namespace Ui {
class salesreport;
}

class salesreport : public QDialog
{
    Q_OBJECT

public:
    explicit salesreport(QWidget *parent = nullptr);
    ~salesreport();

private slots:
    void on_pushButtonD1_clicked();


    void on_pushButtonD2_clicked();

    void on_pushButtonD3_clicked();

    void on_pushButtonD4_clicked();

    void on_pushButtonD5_clicked();

    void on_pushButtonD6_clicked();

    void on_pushButtonD7_clicked();

    void on_pushButtonD1_3_clicked();

    void on_pushButtonD2_3_clicked();

    void on_pushButtonD3_3_clicked();

    void on_pushButtonD4_3_clicked();

    void on_pushButtonD5_3_clicked();

    void on_pushButtonD6_3_clicked();

    void on_pushButtonD7_3_clicked();

    void on_pushButtonD1_4_clicked();

    void on_pushButtonD2_4_clicked();

    void on_pushButtonD3_4_clicked();

    void on_pushButtonD4_4_clicked();

    void on_pushButtonD5_4_clicked();

    void on_pushButtonD6_4_clicked();

    void on_pushButtonD7_4_clicked();

private:
    Ui::salesreport *ui;



};

#endif // SALESREPORT_H
