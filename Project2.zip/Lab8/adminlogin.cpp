#include "adminlogin.h"
#include "ui_adminlogin.h"
#include "admin.h"
#include "QMessageBox"

AdminLogin::AdminLogin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AdminLogin)
{
    ui->setupUi(this);
}

AdminLogin::~AdminLogin()
{
    delete ui;
}

void AdminLogin::on_pushButton_clicked()
{
    if(ui->lineEdit_P->text() == "1111")
    {
        Admin secondDialog;

        secondDialog.setModal(true);
        secondDialog.exec();
    }
    else
    {
        QMessageBox::critical(this,tr("Error"), tr("Invalid Passcode."));
    }
}
