#include "login_db.h"
#include "ui_login_db.h"
#include "displayrebate.h"
#include "expiringmembers.h"
#include "adddelete.h"
#include "adddeleteitems.h"
#include "createpurchases.h"
#include "displayitemssold.h"
#include "salesreport.h"
#include "searchmembernumber.h"
#include "productdisplay.h"
#include "totalpurchases.h"
#include "login.h"
#include "adminlogin.h"

Login_DB::Login_DB(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Login_DB)
{
    ui->setupUi(this);

    QSqlDatabase mydb=QSqlDatabase::addDatabase("QSQLITE");
    mydb.setDatabaseName("E:/Qt/build-Lab8-Desktop_Qt_5_15_0_MinGW_64_bit-Debug/Bulk_Club.db");
    //mydb.setDatabaseName("C:/Users/Heejoo Kim/Desktop/Bulk_Club.db");
    mydb.open();

    QSqlQuery query;

    query.prepare("select * from customers");
    if(!query.exec())
    {
        qDebug() << "ERROR " << query.lastError();
    }
    while(query.next())
    {
        QString variable = query.value(0).toString();

        QSqlQueryModel * modal=new QSqlQueryModel();
        modal->setQuery(query);
        //ui->tableView->setModel(modal);
    }
}

Login_DB::~Login_DB()
{
    delete ui;
}

void Login_DB::on_pushButton_loadTable_clicked()
{
    QSqlQuery query; //qry=new QSqlQuery(mydb);

    query.prepare("select * from customers");
    if(!query.exec())
    {
        //qDebug() << "ERROR " << query.lastError().text;
    }
    while(query.next())
    {
        QString variable = query.value(0).toString();
        qDebug() << variable;

        QSqlQueryModel * modal=new QSqlQueryModel();
        modal->setQuery(query);
        //ui->tableView->setModel(modal);
    }
}

void Login_DB::on_pushButtonGotoSR_4_clicked()
{
    Login secondDialog;

    secondDialog.setModal(true);
    secondDialog.exec();
}

void Login_DB::on_pushButtonGotoSR_5_clicked()
{
    AdminLogin secondDialog;

    secondDialog.setModal(true);
    secondDialog.exec();
}
