#include "convertmembership.h"
#include "ui_convertmembership.h"

convertMembership::convertMembership(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::convertMembership)
{
    ui->setupUi(this);
    displayConvertMembership();
}

convertMembership::~convertMembership()
{
    delete ui;
}

void convertMembership::displayConvertMembership()
{

    QTableWidget *table = new QTableWidget(this);
    table->setRowCount(10);
    table->setColumnCount(5);

    QStringList labels;
    labels << "First Name" << "Last Name" << "ID" << "Membership" <<
                  "Recommendation";
    table->setHorizontalHeaderLabels(labels);

    //Formatting
    table->setMaximumWidth(600);
    table->setMinimumWidth(600);
    table->setMaximumHeight(350);
    table->setMinimumHeight(350);


    //for(int i = 0; i < table->rowCount(); i++)
    //{
    QTableWidgetItem *item;
    item = new QTableWidgetItem;
    item->setText("Sally");
    table->setItem(0, 0, item);
    item = new QTableWidgetItem;
    item->setText("Shopper");
    table->setItem(0,1, item);
    item = new QTableWidgetItem;
    item->setText("12345");
    table->setItem(0,2, item);
    item = new QTableWidgetItem;
    item->setText("Regular");
    table->setItem(0,3, item);
    item = new QTableWidgetItem;
    item->setText("Upgrade");
    table->setItem(0,4, item);

    item = new QTableWidgetItem;
    item->setText("Sally");
    table->setItem(1, 0, item);
    item = new QTableWidgetItem;
    item->setText("Supershopper");
    table->setItem(1,1, item);
    item = new QTableWidgetItem;
    item->setText("61616");
    table->setItem(1,2, item);
    item = new QTableWidgetItem;
    item->setText("Regular");
    table->setItem(1,3, item);
    item = new QTableWidgetItem;
    item->setText("Upgrade");
    table->setItem(1,4, item);

    item = new QTableWidgetItem;
    item->setText("Johnny");
    table->setItem(2, 0, item);
    item = new QTableWidgetItem;
    item->setText("Shopper");
    table->setItem(2,1, item);
    item = new QTableWidgetItem;
    item->setText("12899");
    table->setItem(2,2, item);
    item = new QTableWidgetItem;
    item->setText("Regular");
    table->setItem(2,3, item);
    item = new QTableWidgetItem;
    item->setText("Upgrade");
    table->setItem(2,4, item);

    item = new QTableWidgetItem;
    item->setText("Fred");
    table->setItem(3, 0, item);
    item = new QTableWidgetItem;
    item->setText("Frugal");
    table->setItem(3,1, item);
    item = new QTableWidgetItem;
    item->setText("12897");
    table->setItem(3,2, item);
    item = new QTableWidgetItem;
    item->setText("Executive");
    table->setItem(3,3, item);
    item = new QTableWidgetItem;
    item->setText("Downgrade");
    table->setItem(3,4, item);
//#4
    item = new QTableWidgetItem;
    item->setText("Linda");
    table->setItem(4, 0, item);
    item = new QTableWidgetItem;
    item->setText("Livesalone");
    table->setItem(4,1, item);
    item = new QTableWidgetItem;
    item->setText("35647");
    table->setItem(4,2, item);
    item = new QTableWidgetItem;
    item->setText("Executive");
    table->setItem(4,3, item);
    item = new QTableWidgetItem;
    item->setText("Downgrade");
    table->setItem(4,4, item);

    item = new QTableWidgetItem;
    item->setText("Mary");
    table->setItem(5, 0, item);
    item = new QTableWidgetItem;
    item->setText("IsHappy");
    table->setItem(5,1, item);
    item = new QTableWidgetItem;
    item->setText("96309");
    table->setItem(5,2, item);
    item = new QTableWidgetItem;
    item->setText("Executive");
    table->setItem(5,3, item);
    item = new QTableWidgetItem;
    item->setText("Downgrade");
    table->setItem(5,4, item);

    item = new QTableWidgetItem;
    item->setText("Harry");
    table->setItem(6, 0, item);
    item = new QTableWidgetItem;
    item->setText("Havealotsofkids");
    table->setItem(6,1, item);
    item = new QTableWidgetItem;
    item->setText("12121");
    table->setItem(6,2, item);
    item = new QTableWidgetItem;
    item->setText("Executive");
    table->setItem(6,3, item);
    item = new QTableWidgetItem;
    item->setText("Downgrade");
    table->setItem(6,4, item);

    item = new QTableWidgetItem;
    item->setText("Sue");
    table->setItem(7, 0, item);
    item = new QTableWidgetItem;
    item->setText("Shoparound");
    table->setItem(7,1, item);
    item = new QTableWidgetItem;
    item->setText("56723");
    table->setItem(7,2, item);
    item = new QTableWidgetItem;
    item->setText("Executive");
    table->setItem(7,3, item);
    item = new QTableWidgetItem;
    item->setText("Downgrade");
    table->setItem(7,4, item);

    item = new QTableWidgetItem;
    item->setText("Carrie");
    table->setItem(8, 0, item);
    item = new QTableWidgetItem;
    item->setText("CaresAboutMoney");
    table->setItem(8,1, item);
    item = new QTableWidgetItem;
    item->setText("88888");
    table->setItem(8,2, item);
    item = new QTableWidgetItem;
    item->setText("Executive");
    table->setItem(8,3, item);
    item = new QTableWidgetItem;
    item->setText("Downgrade");
    table->setItem(8,4, item);

    item = new QTableWidgetItem;
    item->setText("Paul");
    table->setItem(9, 0, item);
    item = new QTableWidgetItem;
    item->setText("Pennypincher");
    table->setItem(9,1, item);
    item = new QTableWidgetItem;
    item->setText("24680");
    table->setItem(9,2, item);
    item = new QTableWidgetItem;
    item->setText("Executive");
    table->setItem(9,3, item);
    item = new QTableWidgetItem;
    item->setText("Downgrade");
    table->setItem(9,4, item);

    ui->label_3->setText("3");
    ui->label_4->setText("7");
       // table->setItem(i,i2,item);
      //  }
    //}
//}
}
