#include "admin.h"
#include "ui_admin.h"
#include "login_db.h"
#include "ui_login_db.h"
#include "displayrebate.h"
#include "expiringmembers.h"
#include "adddelete.h"
#include "adddeleteitems.h"
#include "createpurchases.h"
#include "displayitemssold.h"
#include "salesreport.h"
#include "searchmembernumber.h"
#include "productdisplay.h"
#include "totalpurchases.h"
#include "login.h"
#include "convertmembership.h"

Admin::Admin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Admin)
{
    ui->setupUi(this);
}

Admin::~Admin()
{
    delete ui;
}

void Admin::on_pushButtonGotoAD_clicked()
{
    AddDelete secondDialog;

    secondDialog.setModal(true);
    secondDialog.exec();
}

void Admin::on_pushButtonGotoAD_2_clicked()
{
    AddDeleteItems secondDialog;

    secondDialog.setModal(true);
    secondDialog.exec();
}

void Admin::on_pushButtonGotoEM_2_clicked()
{
    CreatePurchases secondDialog;

    secondDialog.setModal(true);
    secondDialog.exec();
}

void Admin::on_pushButtonGotoCM_clicked()
{
    convertMembership secondDialog;

    secondDialog.setModal(true);
    secondDialog.exec();

}
