#ifndef ADMIN_H
#define ADMIN_H

#include <QDialog>

namespace Ui {
class Admin;
}

class Admin : public QDialog
{
    Q_OBJECT

public:
    explicit Admin(QWidget *parent = nullptr);
    ~Admin();

private slots:
    void on_pushButtonGotoAD_clicked();

    void on_pushButtonGotoEM_2_clicked();

    void on_pushButtonGotoAD_2_clicked();

    void on_pushButtonGotoCM_clicked();

private:
    Ui::Admin *ui;
};

#endif // ADMIN_H
