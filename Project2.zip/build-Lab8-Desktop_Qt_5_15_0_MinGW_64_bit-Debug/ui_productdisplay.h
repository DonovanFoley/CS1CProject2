/********************************************************************************
** Form generated from reading UI file 'productdisplay.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PRODUCTDISPLAY_H
#define UI_PRODUCTDISPLAY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_ProductDisplay
{
public:
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QTableView *tableView;
    QPushButton *pushButton;

    void setupUi(QDialog *ProductDisplay)
    {
        if (ProductDisplay->objectName().isEmpty())
            ProductDisplay->setObjectName(QString::fromUtf8("ProductDisplay"));
        ProductDisplay->resize(548, 393);
        label = new QLabel(ProductDisplay);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 70, 56, 16));
        label_2 = new QLabel(ProductDisplay);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 110, 91, 16));
        lineEdit = new QLineEdit(ProductDisplay);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(20, 20, 113, 22));
        lineEdit_2 = new QLineEdit(ProductDisplay);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(110, 70, 113, 22));
        lineEdit_3 = new QLineEdit(ProductDisplay);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(110, 110, 113, 22));
        tableView = new QTableView(ProductDisplay);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(10, 150, 441, 221));
        pushButton = new QPushButton(ProductDisplay);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(150, 20, 93, 28));

        retranslateUi(ProductDisplay);

        QMetaObject::connectSlotsByName(ProductDisplay);
    } // setupUi

    void retranslateUi(QDialog *ProductDisplay)
    {
        ProductDisplay->setWindowTitle(QCoreApplication::translate("ProductDisplay", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("ProductDisplay", "Quantity", nullptr));
        label_2->setText(QCoreApplication::translate("ProductDisplay", "Total Revenue", nullptr));
        pushButton->setText(QCoreApplication::translate("ProductDisplay", "Search", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ProductDisplay: public Ui_ProductDisplay {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PRODUCTDISPLAY_H
