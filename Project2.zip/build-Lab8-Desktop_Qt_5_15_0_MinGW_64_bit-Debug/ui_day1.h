/********************************************************************************
** Form generated from reading UI file 'day1.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DAY1_H
#define UI_DAY1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Day1
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLabel *label;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_E;
    QLabel *label_R;

    void setupUi(QDialog *Day1)
    {
        if (Day1->objectName().isEmpty())
            Day1->setObjectName(QString::fromUtf8("Day1"));
        Day1->resize(948, 564);
        layoutWidget = new QWidget(Day1);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 520, 325, 34));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        label_3 = new QLabel(Day1);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(350, 520, 121, 16));
        label_4 = new QLabel(Day1);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(480, 520, 121, 16));
        label_E = new QLabel(Day1);
        label_E->setObjectName(QString::fromUtf8("label_E"));
        label_E->setGeometry(QRect(370, 540, 55, 16));
        label_R = new QLabel(Day1);
        label_R->setObjectName(QString::fromUtf8("label_R"));
        label_R->setGeometry(QRect(500, 540, 55, 16));

        retranslateUi(Day1);

        QMetaObject::connectSlotsByName(Day1);
    } // setupUi

    void retranslateUi(QDialog *Day1)
    {
        Day1->setWindowTitle(QCoreApplication::translate("Day1", "Dialog", nullptr));
        label_2->setText(QCoreApplication::translate("Day1", "REVENUE FOR THE DAY:", nullptr));
        label->setText(QCoreApplication::translate("Day1", "<html><head/><body><p><br/></p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("Day1", "Number of Executive ", nullptr));
        label_4->setText(QCoreApplication::translate("Day1", "Number of Regular ", nullptr));
        label_E->setText(QString());
        label_R->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Day1: public Ui_Day1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DAY1_H
