/********************************************************************************
** Form generated from reading UI file 'admin.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMIN_H
#define UI_ADMIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Admin
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButtonGotoAD;
    QPushButton *pushButtonGotoEM_2;
    QPushButton *pushButtonGotoAD_2;
    QPushButton *pushButtonGotoCM;

    void setupUi(QDialog *Admin)
    {
        if (Admin->objectName().isEmpty())
            Admin->setObjectName(QString::fromUtf8("Admin"));
        Admin->resize(360, 258);
        widget = new QWidget(Admin);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(69, 60, 201, 151));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        pushButtonGotoAD = new QPushButton(widget);
        pushButtonGotoAD->setObjectName(QString::fromUtf8("pushButtonGotoAD"));
        pushButtonGotoAD->setEnabled(true);

        verticalLayout->addWidget(pushButtonGotoAD);

        pushButtonGotoEM_2 = new QPushButton(widget);
        pushButtonGotoEM_2->setObjectName(QString::fromUtf8("pushButtonGotoEM_2"));
        pushButtonGotoEM_2->setEnabled(true);

        verticalLayout->addWidget(pushButtonGotoEM_2);

        pushButtonGotoAD_2 = new QPushButton(widget);
        pushButtonGotoAD_2->setObjectName(QString::fromUtf8("pushButtonGotoAD_2"));
        pushButtonGotoAD_2->setEnabled(true);

        verticalLayout->addWidget(pushButtonGotoAD_2);


        verticalLayout_2->addLayout(verticalLayout);

        pushButtonGotoCM = new QPushButton(widget);
        pushButtonGotoCM->setObjectName(QString::fromUtf8("pushButtonGotoCM"));
        pushButtonGotoCM->setEnabled(true);

        verticalLayout_2->addWidget(pushButtonGotoCM);


        retranslateUi(Admin);

        QMetaObject::connectSlotsByName(Admin);
    } // setupUi

    void retranslateUi(QDialog *Admin)
    {
        Admin->setWindowTitle(QCoreApplication::translate("Admin", "Dialog", nullptr));
        pushButtonGotoAD->setText(QCoreApplication::translate("Admin", "GoTo Add/Delete", nullptr));
        pushButtonGotoEM_2->setText(QCoreApplication::translate("Admin", "GoTo Create Purchases", nullptr));
        pushButtonGotoAD_2->setText(QCoreApplication::translate("Admin", "GoTo Add/Delete Items", nullptr));
        pushButtonGotoCM->setText(QCoreApplication::translate("Admin", "Membership Upgrade/Downgrade", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Admin: public Ui_Admin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMIN_H
