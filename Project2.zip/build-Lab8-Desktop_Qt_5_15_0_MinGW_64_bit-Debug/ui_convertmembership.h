/********************************************************************************
** Form generated from reading UI file 'convertmembership.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONVERTMEMBERSHIP_H
#define UI_CONVERTMEMBERSHIP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_convertMembership
{
public:
    QTableWidget *tableWidget;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *label_2;
    QWidget *widget1;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_3;
    QLabel *label_4;

    void setupUi(QDialog *convertMembership)
    {
        if (convertMembership->objectName().isEmpty())
            convertMembership->setObjectName(QString::fromUtf8("convertMembership"));
        convertMembership->resize(535, 493);
        tableWidget = new QTableWidget(convertMembership);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(0, 0, 541, 331));
        widget = new QWidget(convertMembership);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(20, 377, 163, 61));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout->addWidget(label_2);

        widget1 = new QWidget(convertMembership);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(190, 370, 131, 71));
        verticalLayout_2 = new QVBoxLayout(widget1);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(widget1);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_2->addWidget(label_3);

        label_4 = new QLabel(widget1);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_2->addWidget(label_4);


        retranslateUi(convertMembership);

        QMetaObject::connectSlotsByName(convertMembership);
    } // setupUi

    void retranslateUi(QDialog *convertMembership)
    {
        convertMembership->setWindowTitle(QCoreApplication::translate("convertMembership", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("convertMembership", "# of Recommended Upgrades:    ", nullptr));
        label_2->setText(QCoreApplication::translate("convertMembership", "# of Recommended Downgrades:", nullptr));
        label_3->setText(QString());
        label_4->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class convertMembership: public Ui_convertMembership {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONVERTMEMBERSHIP_H
