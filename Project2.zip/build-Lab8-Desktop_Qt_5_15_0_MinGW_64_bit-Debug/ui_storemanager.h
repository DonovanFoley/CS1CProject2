/********************************************************************************
** Form generated from reading UI file 'storemanager.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STOREMANAGER_H
#define UI_STOREMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StoreManager
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButtonGotoSR;
    QPushButton *pushButtonGotoSR_3;
    QPushButton *pushButtonGotoDR_2;
    QPushButton *pushButtonGotoDR;
    QPushButton *pushButtonGotoSR_2;
    QPushButton *pushButtonGotoEM;
    QPushButton *pushButtonGotoSM;

    void setupUi(QDialog *StoreManager)
    {
        if (StoreManager->objectName().isEmpty())
            StoreManager->setObjectName(QString::fromUtf8("StoreManager"));
        StoreManager->resize(470, 342);
        layoutWidget = new QWidget(StoreManager);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(140, 10, 181, 321));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButtonGotoSR = new QPushButton(layoutWidget);
        pushButtonGotoSR->setObjectName(QString::fromUtf8("pushButtonGotoSR"));

        verticalLayout->addWidget(pushButtonGotoSR);

        pushButtonGotoSR_3 = new QPushButton(layoutWidget);
        pushButtonGotoSR_3->setObjectName(QString::fromUtf8("pushButtonGotoSR_3"));

        verticalLayout->addWidget(pushButtonGotoSR_3);

        pushButtonGotoDR_2 = new QPushButton(layoutWidget);
        pushButtonGotoDR_2->setObjectName(QString::fromUtf8("pushButtonGotoDR_2"));

        verticalLayout->addWidget(pushButtonGotoDR_2);

        pushButtonGotoDR = new QPushButton(layoutWidget);
        pushButtonGotoDR->setObjectName(QString::fromUtf8("pushButtonGotoDR"));

        verticalLayout->addWidget(pushButtonGotoDR);

        pushButtonGotoSR_2 = new QPushButton(layoutWidget);
        pushButtonGotoSR_2->setObjectName(QString::fromUtf8("pushButtonGotoSR_2"));

        verticalLayout->addWidget(pushButtonGotoSR_2);

        pushButtonGotoEM = new QPushButton(layoutWidget);
        pushButtonGotoEM->setObjectName(QString::fromUtf8("pushButtonGotoEM"));

        verticalLayout->addWidget(pushButtonGotoEM);

        pushButtonGotoSM = new QPushButton(layoutWidget);
        pushButtonGotoSM->setObjectName(QString::fromUtf8("pushButtonGotoSM"));

        verticalLayout->addWidget(pushButtonGotoSM);


        retranslateUi(StoreManager);

        QMetaObject::connectSlotsByName(StoreManager);
    } // setupUi

    void retranslateUi(QDialog *StoreManager)
    {
        StoreManager->setWindowTitle(QCoreApplication::translate("StoreManager", "Dialog", nullptr));
        pushButtonGotoSR->setText(QCoreApplication::translate("StoreManager", "GoTo Sales Report", nullptr));
        pushButtonGotoSR_3->setText(QCoreApplication::translate("StoreManager", "GoTo Total Purchases", nullptr));
        pushButtonGotoDR_2->setText(QCoreApplication::translate("StoreManager", "GoTo Display Item Sold", nullptr));
        pushButtonGotoDR->setText(QCoreApplication::translate("StoreManager", "GoTo Display Rebate", nullptr));
        pushButtonGotoSR_2->setText(QCoreApplication::translate("StoreManager", "GoTo Product Display", nullptr));
        pushButtonGotoEM->setText(QCoreApplication::translate("StoreManager", "GoTo Expiring Members", nullptr));
        pushButtonGotoSM->setText(QCoreApplication::translate("StoreManager", "GoTo Search Members", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StoreManager: public Ui_StoreManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STOREMANAGER_H
