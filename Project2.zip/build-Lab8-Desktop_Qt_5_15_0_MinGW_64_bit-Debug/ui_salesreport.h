/********************************************************************************
** Form generated from reading UI file 'salesreport.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SALESREPORT_H
#define UI_SALESREPORT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_salesreport
{
public:
    QLabel *label;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButtonD1;
    QPushButton *pushButtonD2;
    QPushButton *pushButtonD3;
    QPushButton *pushButtonD4;
    QPushButton *pushButtonD5;
    QPushButton *pushButtonD6;
    QPushButton *pushButtonD7;
    QVBoxLayout *verticalLayout_3;
    QPushButton *pushButtonD1_3;
    QPushButton *pushButtonD2_3;
    QPushButton *pushButtonD3_3;
    QPushButton *pushButtonD4_3;
    QPushButton *pushButtonD5_3;
    QPushButton *pushButtonD6_3;
    QPushButton *pushButtonD7_3;
    QVBoxLayout *verticalLayout_4;
    QPushButton *pushButtonD1_4;
    QPushButton *pushButtonD2_4;
    QPushButton *pushButtonD3_4;
    QPushButton *pushButtonD4_4;
    QPushButton *pushButtonD5_4;
    QPushButton *pushButtonD6_4;
    QPushButton *pushButtonD7_4;
    QWidget *widget1;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;

    void setupUi(QDialog *salesreport)
    {
        if (salesreport->objectName().isEmpty())
            salesreport->setObjectName(QString::fromUtf8("salesreport"));
        salesreport->resize(550, 605);
        label = new QLabel(salesreport);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(210, 20, 311, 31));
        widget = new QWidget(salesreport);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(30, 150, 471, 391));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        pushButtonD1 = new QPushButton(widget);
        pushButtonD1->setObjectName(QString::fromUtf8("pushButtonD1"));

        verticalLayout->addWidget(pushButtonD1);

        pushButtonD2 = new QPushButton(widget);
        pushButtonD2->setObjectName(QString::fromUtf8("pushButtonD2"));

        verticalLayout->addWidget(pushButtonD2);

        pushButtonD3 = new QPushButton(widget);
        pushButtonD3->setObjectName(QString::fromUtf8("pushButtonD3"));

        verticalLayout->addWidget(pushButtonD3);

        pushButtonD4 = new QPushButton(widget);
        pushButtonD4->setObjectName(QString::fromUtf8("pushButtonD4"));

        verticalLayout->addWidget(pushButtonD4);

        pushButtonD5 = new QPushButton(widget);
        pushButtonD5->setObjectName(QString::fromUtf8("pushButtonD5"));

        verticalLayout->addWidget(pushButtonD5);

        pushButtonD6 = new QPushButton(widget);
        pushButtonD6->setObjectName(QString::fromUtf8("pushButtonD6"));

        verticalLayout->addWidget(pushButtonD6);

        pushButtonD7 = new QPushButton(widget);
        pushButtonD7->setObjectName(QString::fromUtf8("pushButtonD7"));

        verticalLayout->addWidget(pushButtonD7);


        horizontalLayout->addLayout(verticalLayout);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        pushButtonD1_3 = new QPushButton(widget);
        pushButtonD1_3->setObjectName(QString::fromUtf8("pushButtonD1_3"));

        verticalLayout_3->addWidget(pushButtonD1_3);

        pushButtonD2_3 = new QPushButton(widget);
        pushButtonD2_3->setObjectName(QString::fromUtf8("pushButtonD2_3"));

        verticalLayout_3->addWidget(pushButtonD2_3);

        pushButtonD3_3 = new QPushButton(widget);
        pushButtonD3_3->setObjectName(QString::fromUtf8("pushButtonD3_3"));

        verticalLayout_3->addWidget(pushButtonD3_3);

        pushButtonD4_3 = new QPushButton(widget);
        pushButtonD4_3->setObjectName(QString::fromUtf8("pushButtonD4_3"));

        verticalLayout_3->addWidget(pushButtonD4_3);

        pushButtonD5_3 = new QPushButton(widget);
        pushButtonD5_3->setObjectName(QString::fromUtf8("pushButtonD5_3"));

        verticalLayout_3->addWidget(pushButtonD5_3);

        pushButtonD6_3 = new QPushButton(widget);
        pushButtonD6_3->setObjectName(QString::fromUtf8("pushButtonD6_3"));

        verticalLayout_3->addWidget(pushButtonD6_3);

        pushButtonD7_3 = new QPushButton(widget);
        pushButtonD7_3->setObjectName(QString::fromUtf8("pushButtonD7_3"));

        verticalLayout_3->addWidget(pushButtonD7_3);


        horizontalLayout->addLayout(verticalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        pushButtonD1_4 = new QPushButton(widget);
        pushButtonD1_4->setObjectName(QString::fromUtf8("pushButtonD1_4"));

        verticalLayout_4->addWidget(pushButtonD1_4);

        pushButtonD2_4 = new QPushButton(widget);
        pushButtonD2_4->setObjectName(QString::fromUtf8("pushButtonD2_4"));

        verticalLayout_4->addWidget(pushButtonD2_4);

        pushButtonD3_4 = new QPushButton(widget);
        pushButtonD3_4->setObjectName(QString::fromUtf8("pushButtonD3_4"));

        verticalLayout_4->addWidget(pushButtonD3_4);

        pushButtonD4_4 = new QPushButton(widget);
        pushButtonD4_4->setObjectName(QString::fromUtf8("pushButtonD4_4"));

        verticalLayout_4->addWidget(pushButtonD4_4);

        pushButtonD5_4 = new QPushButton(widget);
        pushButtonD5_4->setObjectName(QString::fromUtf8("pushButtonD5_4"));

        verticalLayout_4->addWidget(pushButtonD5_4);

        pushButtonD6_4 = new QPushButton(widget);
        pushButtonD6_4->setObjectName(QString::fromUtf8("pushButtonD6_4"));

        verticalLayout_4->addWidget(pushButtonD6_4);

        pushButtonD7_4 = new QPushButton(widget);
        pushButtonD7_4->setObjectName(QString::fromUtf8("pushButtonD7_4"));

        verticalLayout_4->addWidget(pushButtonD7_4);


        horizontalLayout->addLayout(verticalLayout_4);

        widget1 = new QWidget(salesreport);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(40, 110, 451, 21));
        horizontalLayout_2 = new QHBoxLayout(widget1);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(widget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        label_3 = new QLabel(widget1);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        label_4 = new QLabel(widget1);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_2->addWidget(label_4);


        retranslateUi(salesreport);

        QMetaObject::connectSlotsByName(salesreport);
    } // setupUi

    void retranslateUi(QDialog *salesreport)
    {
        salesreport->setWindowTitle(QCoreApplication::translate("salesreport", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("salesreport", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">SALES REPORT</span></p></body></html>", nullptr));
        pushButtonD1->setText(QCoreApplication::translate("salesreport", "DAY 1", nullptr));
        pushButtonD2->setText(QCoreApplication::translate("salesreport", "DAY 2", nullptr));
        pushButtonD3->setText(QCoreApplication::translate("salesreport", "DAY 3", nullptr));
        pushButtonD4->setText(QCoreApplication::translate("salesreport", "DAY 4", nullptr));
        pushButtonD5->setText(QCoreApplication::translate("salesreport", "DAY 5", nullptr));
        pushButtonD6->setText(QCoreApplication::translate("salesreport", "DAY6 ", nullptr));
        pushButtonD7->setText(QCoreApplication::translate("salesreport", "DAY 7", nullptr));
        pushButtonD1_3->setText(QCoreApplication::translate("salesreport", "DAY 1", nullptr));
        pushButtonD2_3->setText(QCoreApplication::translate("salesreport", "DAY 2", nullptr));
        pushButtonD3_3->setText(QCoreApplication::translate("salesreport", "DAY 3", nullptr));
        pushButtonD4_3->setText(QCoreApplication::translate("salesreport", "DAY 4", nullptr));
        pushButtonD5_3->setText(QCoreApplication::translate("salesreport", "DAY 5", nullptr));
        pushButtonD6_3->setText(QCoreApplication::translate("salesreport", "DAY6 ", nullptr));
        pushButtonD7_3->setText(QCoreApplication::translate("salesreport", "DAY 7", nullptr));
        pushButtonD1_4->setText(QCoreApplication::translate("salesreport", "DAY 1", nullptr));
        pushButtonD2_4->setText(QCoreApplication::translate("salesreport", "DAY 2", nullptr));
        pushButtonD3_4->setText(QCoreApplication::translate("salesreport", "DAY 3", nullptr));
        pushButtonD4_4->setText(QCoreApplication::translate("salesreport", "DAY 4", nullptr));
        pushButtonD5_4->setText(QCoreApplication::translate("salesreport", "DAY 5", nullptr));
        pushButtonD6_4->setText(QCoreApplication::translate("salesreport", "DAY6 ", nullptr));
        pushButtonD7_4->setText(QCoreApplication::translate("salesreport", "DAY 7", nullptr));
        label_2->setText(QCoreApplication::translate("salesreport", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600;\">TOTAL</span></p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("salesreport", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600;\">REGULAR</span></p></body></html>", nullptr));
        label_4->setText(QCoreApplication::translate("salesreport", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600;\">EXECUTIVE</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class salesreport: public Ui_salesreport {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SALESREPORT_H
