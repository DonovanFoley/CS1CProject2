/********************************************************************************
** Form generated from reading UI file 'searchmembernumber.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEARCHMEMBERNUMBER_H
#define UI_SEARCHMEMBERNUMBER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SearchMemberNumber
{
public:
    QTableWidget *tableWidget;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLabel *label_2;
    QLabel *label_3;
    QPushButton *pushButton_2;
    QLabel *label_4;
    QLabel *label_5;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QPushButton *pushButton;
    QLabel *label_8;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_6;
    QLabel *label_7;

    void setupUi(QDialog *SearchMemberNumber)
    {
        if (SearchMemberNumber->objectName().isEmpty())
            SearchMemberNumber->setObjectName(QString::fromUtf8("SearchMemberNumber"));
        SearchMemberNumber->resize(651, 550);
        tableWidget = new QTableWidget(SearchMemberNumber);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(10, 0, 441, 431));
        lineEdit_2 = new QLineEdit(SearchMemberNumber);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(370, 470, 131, 20));
        lineEdit_3 = new QLineEdit(SearchMemberNumber);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(370, 500, 131, 20));
        label_2 = new QLabel(SearchMemberNumber);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(300, 470, 71, 16));
        label_3 = new QLabel(SearchMemberNumber);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(300, 500, 71, 16));
        pushButton_2 = new QPushButton(SearchMemberNumber);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(510, 470, 81, 51));
        label_4 = new QLabel(SearchMemberNumber);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(476, 160, 171, 31));
        label_5 = new QLabel(SearchMemberNumber);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(480, 200, 141, 31));
        layoutWidget = new QWidget(SearchMemberNumber);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(30, 470, 251, 51));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        lineEdit = new QLineEdit(layoutWidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        horizontalLayout->addWidget(lineEdit);

        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        horizontalLayout->addWidget(pushButton);

        label_8 = new QLabel(SearchMemberNumber);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(460, 80, 101, 31));
        layoutWidget1 = new QWidget(SearchMemberNumber);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(460, 30, 181, 31));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(layoutWidget1);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_2->addWidget(label_6);

        label_7 = new QLabel(layoutWidget1);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_2->addWidget(label_7);


        retranslateUi(SearchMemberNumber);
        QObject::connect(lineEdit, SIGNAL(returnPressed()), pushButton, SLOT(click()));

        QMetaObject::connectSlotsByName(SearchMemberNumber);
    } // setupUi

    void retranslateUi(QDialog *SearchMemberNumber)
    {
        SearchMemberNumber->setWindowTitle(QCoreApplication::translate("SearchMemberNumber", "Dialog", nullptr));
        label_2->setText(QCoreApplication::translate("SearchMemberNumber", "First Name", nullptr));
        label_3->setText(QCoreApplication::translate("SearchMemberNumber", "Last Name", nullptr));
        pushButton_2->setText(QCoreApplication::translate("SearchMemberNumber", "Search", nullptr));
        label_4->setText(QCoreApplication::translate("SearchMemberNumber", "Total Amount of Purchase:", nullptr));
        label_5->setText(QCoreApplication::translate("SearchMemberNumber", "<html><head/><body><p>0.00</p></body></html>", nullptr));
        label->setText(QCoreApplication::translate("SearchMemberNumber", "Membership #:", nullptr));
        pushButton->setText(QCoreApplication::translate("SearchMemberNumber", "Search", nullptr));
        label_8->setText(QCoreApplication::translate("SearchMemberNumber", "Member ID", nullptr));
        label_6->setText(QCoreApplication::translate("SearchMemberNumber", "First Name", nullptr));
        label_7->setText(QCoreApplication::translate("SearchMemberNumber", "Last Name", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SearchMemberNumber: public Ui_SearchMemberNumber {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEARCHMEMBERNUMBER_H
