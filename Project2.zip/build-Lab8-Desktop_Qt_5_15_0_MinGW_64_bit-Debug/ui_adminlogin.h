/********************************************************************************
** Form generated from reading UI file 'adminlogin.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINLOGIN_H
#define UI_ADMINLOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_AdminLogin
{
public:
    QPushButton *pushButton;
    QLabel *label_2;
    QLineEdit *lineEdit_P;
    QLabel *label;

    void setupUi(QDialog *AdminLogin)
    {
        if (AdminLogin->objectName().isEmpty())
            AdminLogin->setObjectName(QString::fromUtf8("AdminLogin"));
        AdminLogin->resize(196, 117);
        pushButton = new QPushButton(AdminLogin);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(90, 80, 75, 24));
        label_2 = new QLabel(AdminLogin);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 50, 111, 16));
        lineEdit_P = new QLineEdit(AdminLogin);
        lineEdit_P->setObjectName(QString::fromUtf8("lineEdit_P"));
        lineEdit_P->setGeometry(QRect(70, 50, 113, 22));
        label = new QLabel(AdminLogin);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 0, 171, 31));

        retranslateUi(AdminLogin);

        QMetaObject::connectSlotsByName(AdminLogin);
    } // setupUi

    void retranslateUi(QDialog *AdminLogin)
    {
        AdminLogin->setWindowTitle(QCoreApplication::translate("AdminLogin", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("AdminLogin", "Login", nullptr));
        label_2->setText(QCoreApplication::translate("AdminLogin", "Passcode:", nullptr));
        label->setText(QCoreApplication::translate("AdminLogin", "Administator login", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AdminLogin: public Ui_AdminLogin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINLOGIN_H
